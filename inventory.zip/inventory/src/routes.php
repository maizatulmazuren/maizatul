<?php

//hello route
require __DIR__ . '/Controllers/hello.php';

//products route
require __DIR__ . '/Controllers/product.php';

